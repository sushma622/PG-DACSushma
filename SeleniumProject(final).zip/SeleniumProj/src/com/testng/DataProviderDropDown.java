package com.testng;

import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.DataProvider;

public class DataProviderDropDown {
  @Test(dataProvider = "dp")
  public void f(String s,String n) {
	  System.setProperty("webdriver.chrome.driver","D:\\\\Selenium Data\\\\chromedriver-win32\\\\chromedriver-win32\\\\chromedriver.exe");
	  WebDriver dr=new ChromeDriver();
	  dr.get("https://demo.automationtesting.in/Register.html");
	  
	  dr.findElement(By.xpath("//body/section[@id='section']/div[1]/div[1]/div[2]/form[1]/div[1]/div[1]/input[1]")).sendKeys(s);
	  Select skills=new Select(dr.findElement(By.id("Skills")));
	     //skills.selectByIndex(10);//
	     skills.selectByVisibleText(n);
  }

  @DataProvider
  public Object[][] dp() {
    return new Object[][] {
      new Object[] {"Rutuja","CSS"},
      //new Object[] { 2, "b" },
    };
  }
}
