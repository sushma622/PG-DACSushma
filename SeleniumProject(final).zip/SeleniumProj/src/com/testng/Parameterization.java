package com.testng;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Parameterization {
	public static WebDriver d; 
	@Parameters({"un","pwd"})
  @Test(priority = 1)
  public void f(String un,String pwd) throws InterruptedException {
	  d.findElement(By.xpath("//input[@id='user-name']")).sendKeys(un);
	  d.findElement(By.xpath("//input[@id='password']")).sendKeys(pwd);
	  d.findElement(By.xpath("//input[@id='login-button']")).click();
	  
	
	  //d.findElement(By.xpath("//input[@id='user-name']")).clear();
	 // d.findElement(By.xpath("//input[@id='password']")).clear();
	  Thread.sleep(1000);

  }
	
	@Parameters({"un1","pwd1"})
	  @Test(priority = 2)
	  public void f2(String un1,String pwd1) {
		d.findElement(By.xpath("//input[@id='user-name']")).clear();
		d.findElement(By.xpath("//input[@id='user-name']")).sendKeys(un1);
		
		  d.findElement(By.xpath("//input[@id='password']")).clear();
		  d.findElement(By.xpath("//input[@id='password']")).sendKeys(pwd1);
		  
		  d.findElement(By.xpath("//input[@id='login-button']")).click();
	  }
  
  @BeforeTest
  public void beforeTest() {
	  System.setProperty("webdriver.chrome.driver","D:\\Selenium Data\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");
	  d=new ChromeDriver();
	     
	     d.get("https://www.saucedemo.com/v1/");
	     d.manage().window().maximize();
  }
  
  
}
