package com.testng;

import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;

public class DataProviderDemo {
	public static WebDriver d; 
  @Test(dataProvider = "dp")
  public void login(String n, String s) throws InterruptedException {
	  System.setProperty("webdriver.chrome.driver","D:\\Selenium Data\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");
	  d=new ChromeDriver();
	     
	     d.get("https://demo.guru99.com/v4/");
	     
	     d.findElement(By.xpath("//tbody/tr[1]/td[2]/input[1]")).sendKeys(n);
	     d.findElement(By.xpath("//tbody/tr[2]/td[2]/input[1]")).sendKeys(s);
	     Thread.sleep(1000);
	     d.findElement(By.xpath("//tbody/tr[3]/td[2]/input[1]")).click();
  }

  @DataProvider
  public Object[][] dp() {
    return new Object[][] {
      new Object[] { "abcd", "1234" },
      new Object[] { "mngr547859", "vevUtAr" },
    };
  }
}
