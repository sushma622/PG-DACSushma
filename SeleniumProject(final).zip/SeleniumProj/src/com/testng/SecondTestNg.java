package com.testng;

import org.testng.SkipException;
import org.testng.annotations.Test;

public class SecondTestNg {
  @Test(priority = 'a')
  public void login() {
	  System.out.println("I am in login");
  }
  
  @Test(priority ='a')
  public void reg() {
	  System.out.println("I am in registration");
  }
  
  @Test
  public void logout() {
	  System.out.println("I am in logout");
	  throw new SkipException("I am skipping because of interruption");
  }
}
