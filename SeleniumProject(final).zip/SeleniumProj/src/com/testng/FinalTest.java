package com.testng;

import org.testng.annotations.Test;

public class FinalTest {
  @Test
  public void f() {
	  System.out.println("In finalTest class");
  }
}
