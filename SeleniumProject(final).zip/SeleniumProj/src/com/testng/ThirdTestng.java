package com.testng;

import org.testng.annotations.Test;

public class ThirdTestng {
  @Test
  public void f() {
	  System.out.println("Third test class");
  }
}
