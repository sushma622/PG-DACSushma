package com.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleniumTest {

	public static void main(String[] args) {
		 System.setProperty("webdriver.chrome.driver","D:\\Selenium Data\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");
      
          WebDriver d=new ChromeDriver();
          //d.get("https://www.saucedemo.com/v1/");
          
          d.get("https://demo.guru99.com/v4/");
//          d.findElement(By.xpath("//input[@id='user-name']")).sendKeys("standard_user");
//          d.findElement(By.xpath("//input[@id='password']")).sendKeys("secret_sauce");
//          
//          d.findElement(By.id("user-name")).sendKeys("standard_user");
//          d.findElement(By.id("password")).sendKeys("secret_sauce");
//         //d.findElement(By.xpath("//input[@id='login-button']")).click();
//          
//          d.findElement(By.id("login-button")).click();
          
         
//          d.findElement(By.id("user-name")).sendKeys("standard_user");
//          d.findElement(By.id("password")).sendKeys("secret_sauce");
//         //d.findElement(By.xpath("//input[@id='login-button']")).click();
//          
//          d.findElement(By.id("login-button")).click();
          
          d.findElement(By.linkText("here")).click(); 
          
          
          }

}
