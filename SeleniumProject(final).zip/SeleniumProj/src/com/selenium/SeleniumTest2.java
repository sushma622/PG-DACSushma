package com.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleniumTest2 {

	public static void main(String[] args) {
		 System.setProperty("webdriver.chrome.driver","D:\\Selenium Data\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");
	     WebDriver d=new ChromeDriver();
	     
//	     d.get("https://petstore.octoperf.com/actions/Catalog.action");
//	     d.findElement(By.linkText("here")).click(); 
//	     d.manage().window().maximize();
	     
	     System.out.println("Page Title:-"+d.getTitle());
	     
//	     d.findElement(By.linkText("Sign In")).click();
//	     
//	     d.findElement(By.name("username")).sendKeys("rk");
//	     d.findElement(By.name("password")).sendKeys("rk@1234");
//	     d.findElement(By.name("signon")).click();
	     
	     d.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
	     
	     d.findElement(By.name("username")).sendKeys("Admin");
	     d.findElement(By.name("password")).sendKeys("admin123");
	     d.findElement(By.name("submit")).click();
	     

	}

}
