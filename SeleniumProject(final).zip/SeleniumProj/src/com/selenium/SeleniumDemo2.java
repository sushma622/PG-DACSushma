package com.selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class SeleniumDemo2 {

	public static void main(String[] args) {
		 System.setProperty("webdriver.firefox.driver","D:\\Selenium Data\\geckodriver-v0.34.0-win32\\geckodriver.exe");
         // ChromeOptions co=new ChromeOptions();
          WebDriver obj=new FirefoxDriver();
         obj.get("https://www.google.com");
          //obj.get("https://demo.guru99.com/v4/");
          
          System.out.println(obj.getTitle());

	}

}
