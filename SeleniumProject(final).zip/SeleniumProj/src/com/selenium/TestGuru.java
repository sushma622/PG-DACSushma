package com.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestGuru {

	public static void main(String[] args) throws InterruptedException {
		
		 System.setProperty("webdriver.chrome.driver","D:\\Selenium Data\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");
	     WebDriver d=new ChromeDriver();
	     
	     d.get("https://demo.guru99.com/v4/");
	     d.manage().window().maximize();
	     
	     WebElement we=d.findElement(By.xpath("//tbody/tr[1]/td[2]/input[1]"));
//	     we.click();
//	     Thread.sleep(1000);
//	     we.sendKeys("JHFGTES");
//	     Thread.sleep(1000);
//	     we.clear();
//	     Thread.sleep(1000);
	     we.sendKeys("PQRSTU");
	    
	     String v=we.getAttribute("value");
	     System.out.println(v);
	     
	     Thread.sleep(1000);
	     we.clear();
	     
	     d.findElement(By.xpath("//tbody/tr[2]/td[2]/input[1]")).click();
	     
	     String msg=d.findElement(By.xpath("//label[@id='message23']")).getText();
	     System.out.println(msg);
	     
         WebElement we2=d.findElement(By.xpath("//tbody/tr[2]/td[2]/input[1]"));
         we2.click();
         we2.sendKeys("Rutu@1234");
         we2.clear();
         
         String msg2=d.findElement(By.xpath("//label[@id='message18']")).getText();
         System.out.println(msg2);
	     
//	     d.findElement(By.xpath("//tbody/tr[1]/td[2]/input[1]")).click();
//	     
//	     Thread.sleep(1000);
//	     d.findElement(By.xpath("//tbody/tr[1]/td[2]/input[1]")).sendKeys("wygghgdgagd");
//	     
//	     Thread.sleep(1000);
//	    d.findElement(By.xpath("//tbody/tr[1]/td[2]/input[1]")).clear();
//	    
//	    Thread.sleep(1000);
//	    d.findElement(By.xpath("//tbody/tr[1]/td[2]/input[1]")).sendKeys("PQR");
         
         WebElement login=d.findElement(By.xpath("//tbody/tr[3]/td[2]/input[1]"));
         login.click();

	}

}
