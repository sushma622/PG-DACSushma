package com.selenium;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AutomationDemo2 {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver","D:\\Selenium Data\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");
	     WebDriver dr=new ChromeDriver();
	     
	     dr.get("https://demo.automationtesting.in/Alerts.html");
	     
	     Thread.sleep(1000);
	     dr.findElement(By.xpath("//body/div[1]/div[1]/div[1]/div[1]/div[1]/ul[1]/li[1]/a[1]")).click();
	     dr.findElement(By.xpath("//button[contains(text(),'alert box:')]")).click();
         
	    Alert a=dr.switchTo().alert();
	    String amsg=a.getText();
	    System.out.println(amsg);
	    a.accept();
	    
	    dr.findElement(By.xpath("//a[contains(text(),'Alert with OK & Cancel')]")).click();
	    dr.findElement(By.xpath("//button[contains(text(),'click the button to display a confirm box')]")).click();
	    System.out.println("==================================");
	    System.out.println(a.getText());
	   
	    Thread.sleep(1000);
	    a.accept();
	    System.out.println("==================================");
	    String str=dr.findElement(By.xpath("//p[@id='demo']")).getText();
	    System.out.println(str);
	    
	    Thread.sleep(1000);
	    dr.findElement(By.xpath("//button[contains(text(),'click the button to display a confirm box')]")).click();
	    a.dismiss();
	    System.out.println("==================================");
	    String str1=dr.findElement(By.xpath("//p[@id='demo']")).getText();
	    System.out.println(str1);
	    
	    
	    Thread.sleep(1000);
	    dr.findElement(By.xpath("//a[contains(text(),'Alert with Textbox')]")).click();
	    dr.findElement(By.xpath("//button[contains(text(),'click the button to demonstrate the prompt box')]")).click();
	    a.sendKeys("Rutuja");
	   a.accept();
	    System.out.println("==========================================");
      String str2=dr.findElement(By.xpath("//p[@id='demo1']")).getText();
      System.out.println(str2);
	     
	}

}
