package com.selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.chrome.ChromeDriver;

public class TabHandling {

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver","D:\\Selenium Data\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");
	     WebDriver dr=new ChromeDriver();
	     
	    dr.get("https://www.google.co.in/");
	    

//	     String fw=dr.getWindowHandle();
//	     dr.switchTo().newWindow(WindowType.TAB);
//	     dr.get("https://demo.automationtesting.in/Alerts.html");
//	     dr.switchTo().window(fw);
	     
	    String fw=dr.getWindowHandle();
	    
	    dr.switchTo().newWindow(WindowType.TAB);
	    dr.get("https://demo.automationtesting.in/Alerts.html");
	    
	    String fw1=dr.getWindowHandle();
	    
	    dr.switchTo().newWindow(WindowType.TAB);
	    dr.get("https://petstore.octoperf.com/actions/Catalog.action");
	    String fw2=dr.getWindowHandle();
//	    dr.switchTo().window(fw1);
//	   
//	    Thread.sleep(1000);
//	    dr.switchTo().window(fw2);
	    
	    Thread.sleep(1000);
	    dr.switchTo().window(fw);
	    
	    Thread.sleep(1000);
	    dr.switchTo().window(fw);
	    
	    Thread.sleep(1000);
	    dr.switchTo().window(fw1);
	    
	    Thread.sleep(1000);
	    dr.switchTo().window(fw2);
	    
	    Thread.sleep(1000);
	    dr.switchTo().window(fw).close();
	}

}
