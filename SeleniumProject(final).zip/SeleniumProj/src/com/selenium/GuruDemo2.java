package com.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class GuruDemo2 {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver","D:\\Selenium Data\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");
	     WebDriver dr=new ChromeDriver();
	     
	     dr.get("https://demo.guru99.com/v4/");
	     dr.manage().window().maximize();

	     dr.findElement(By.xpath("//body/div[1]/div[2]/nav[1]/div[1]/div[1]/ul[1]/li[1]/a[1]")).click();
	     dr.findElement(By.xpath("//a[contains(text(),'Radio & Checkbox Demo')]")).click();
	     
	     
	}

}
