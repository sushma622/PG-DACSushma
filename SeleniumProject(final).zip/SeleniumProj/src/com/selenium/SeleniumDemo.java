package com.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class SeleniumDemo {

	public static void main(String[] args) throws InterruptedException {
	    
           System.setProperty("webdriver.chrome.driver","D:\\Selenium Data\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");
          // ChromeOptions co=new ChromeOptions();
           WebDriver d=new ChromeDriver();
           
//           d.manage().window().maximize();
//           d.get("https://chromedriver.chromium.org");
          
           
          // d.get("https://www.google.com");
//           d.navigate().to("https://www.google.com");//without get open a web page
//           d.manage().window().maximize();
           d.get("https://www.saucedemo.com/v1/");
           d.findElement(By.xpath("//input[@id='user-name']"));
           //d.get("https://www.w3schools.com");
           d.navigate().back();
           
           
           //WebDriver d=new ChromeDriver();//its open the page in another browser
//          d.get("https://www.gmail.com");
          //Thread.sleep(5000);
//          d.manage().window().maximize();
//          d.manage().window().minimize();
          //d.close();
          //System.out.println(d.getTitle());
//           String title="Google";
//           
//           System.out.println("============================");
//           if(title.equals(d.getTitle()))
//           {
//        	   System.out.println("True");
//           }
//           else {
//        	   System.out.println("False");
//           }
//		
//           System.out.println("=================================");
//           System.out.println("Curent Url:-"+ d.getCurrentUrl());
//           
//           System.out.println("=================================");
//           System.out.println(d.getPageSource());//gives html design of page
	}
}
