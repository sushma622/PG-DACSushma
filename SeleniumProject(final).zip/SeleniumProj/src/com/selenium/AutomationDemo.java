package com.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class AutomationDemo {

	public static void main(String[] args) {
		
		 System.setProperty("webdriver.chrome.driver","D:\\Selenium Data\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");
	     WebDriver d=new ChromeDriver();
	     
	     d.get("https://demo.automationtesting.in/Register.html");
	     d.manage().window().maximize();
      
	     d.findElement(By.xpath("//body/section[@id='section']/div[1]/div[1]/div[2]/form[1]/div[1]/div[1]/input[1]")).sendKeys("Rutuja");
	     d.findElement(By.xpath("//body/section[@id='section']/div[1]/div[1]/div[2]/form[1]/div[1]/div[2]/input[1]")).sendKeys("Kamble");
	     d.findElement(By.xpath("//body/section[@id='section']/div[1]/div[1]/div[2]/form[1]/div[2]/div[1]/textarea[1]")).sendKeys("Karad,Maharashtra");
	     d.findElement(By.xpath("//body/section[@id='section']/div[1]/div[1]/div[2]/form[1]/div[3]/div[1]/input[1]")).sendKeys("rutujakamble437@gmail.com");
	     d.findElement(By.xpath("//body/section[@id='section']/div[1]/div[1]/div[2]/form[1]/div[4]/div[1]/input[1]")).sendKeys("7719858494");
	     d.findElement(By.xpath("//body/section[@id='section']/div[1]/div[1]/div[2]/form[1]/div[5]/div[1]/label[2]/input[1]")).click();
	     d.findElement(By.xpath("//input[@id='checkbox2']")).click();
	     d.findElement(By.xpath("//input[@id='checkbox1']")).click();
	   
	     Select skills=new Select(d.findElement(By.xpath("//select[@id='Skills']")));
	     //skills.selectByIndex(10);//
	     skills.selectByVisibleText("Android");
	     //d.findElement(By.xpath(""))
	     
	     Select country=new Select(d.findElement(By.id("country")));
	     country.selectByIndex(5);
	     
	     Select year=new Select(d.findElement(By.id("yearbox")));
	     year.selectByValue("2000");
	     
	     Select month=new Select(d.findElement(By.xpath("//body/section[@id='section']/div[1]/div[1]/div[2]/form[1]/div[11]/div[2]/select[1]")));
	     month.selectByVisibleText("December");
	     
	     Select day=new Select(d.findElement(By.xpath("//select[@id='daybox']")));
	     day.selectByValue("12");
	   
	     d.findElement(By.xpath("//input[@id='firstpassword']")).sendKeys("Rutuja@1234");
	     d.findElement(By.xpath("//input[@id='secondpassword']")).sendKeys("Rutuja@1234");
	}

}
