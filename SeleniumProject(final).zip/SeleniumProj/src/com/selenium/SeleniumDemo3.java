package com.selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleniumDemo3 {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver","D:\\Selenium Data\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");
       
         WebDriver d=new ChromeDriver();
         //d.get("https://www.google.com");
         d.get("https://demo.guru99.com/v4/");
         System.out.println(d.getTitle());

	}

}
