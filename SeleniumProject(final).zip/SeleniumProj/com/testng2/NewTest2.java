package com.testng2;

import org.testng.annotations.Test;

public class NewTest2 {
  @Test
  public void f() {
  }
}
